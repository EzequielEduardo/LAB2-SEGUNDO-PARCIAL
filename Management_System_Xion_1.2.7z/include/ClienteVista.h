#define FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED
#ifndef CLIENTEVISTA_H
#define CLIENTEVISTA_H
#include "ClienteFile.h"
#include "ClienteNegocio.h"

class ClienteVista
{

	private:


	public:



	void mostrarCliente(ClienteNegocio ID);
	void cargarCliente(ClienteNegocio ID);


};

#endif // CLIENTEVISTA_H
